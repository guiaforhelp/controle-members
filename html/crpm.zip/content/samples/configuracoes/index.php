<?php

registreScript(array(            
    enqueueScript('jquery-3.6.3', false, false, 'jquery-3.6.3.min', false, false, true, false),
    enqueueScript('ajax', false, 'ajax', false, false, true, false),          
    enqueueStyle('configuracoes', 'configuracoes', false, false)
));
?>

<div class="panel">
    <div class="container-all-list">
        <span>Esta é uma versão beta que ainda se encontra <br> em denvolvimento por Miquéias Silva</span>
    </div>
</div>