<?php
require 'init.php';

listMembersAddUser($id_page);
?>