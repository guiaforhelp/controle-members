<?php
require 'init.php';

echo '<h3>Aqui será aonde irá mostrar o histórico do membros<br> 
removidos do banco de dados e serão restaurados caso necessário</h3>';
?>