<?php

registreScript(array(            
    enqueueScript('jquery-3.6.3', false, 'jquery-3.6.3.min', false, false, true, false),
    enqueueScript('ajax', false, 'ajax', false, false, true, false),          
    enqueueStyle('add-user', 'add-user', false, false),
    enqueueStyle('users-whatsapp', 'users-whatsapp', false, false)
));
?>

<div class="panel">
    <!-- Lista de usuário -->
    <div class="container-all-list">
            
            <table>
                <thead>
                    <tr>
                        <th>Ação</th>  
                        <th>Nome</th>                 
                        <th>Validade carteirinha</th>
                        <th>Situação do membro</th>
                        <th>Cargo</th>                                      
                    </tr>
                </thead>
    
                <tbody>
                    <tr>
                    <td>
                            <a href="#">Conversar</a>
                        </td>
                        <td>
                            <a href="#">Miquéias Silva</a>
                        </td>   
                        <td>30/05/2025</td>             
                        <td>Ativo</td>
                        <td>Levita</td>                    
                    </tr>    
                    <tr>
                    <td>
                            <a href="#">Conversar</a>
                        </td>
                        <td>
                            <a href="#">Miquéias Silva</a>
                        </td>   
                        <td>30/05/2025</td>             
                        <td>Ativo</td>
                        <td>Levita</td>                    
                    </tr>    
                    <tr>
                    <td>
                            <a href="#">Conversar</a>
                        </td>
                        <td>
                            <a href="#">Miquéias Silva</a>
                        </td>   
                        <td>30/05/2025</td>             
                        <td>Ativo</td>
                        <td>Levita</td>                    
                    </tr>    
                    <tr>
                    <td>
                            <a href="#">Conversar</a>
                        </td>
                        <td>
                            <a href="#">Miquéias Silva</a>
                        </td>   
                        <td>30/05/2025</td>             
                        <td>Ativo</td>
                        <td>Levita</td>                    
                    </tr>    
                    <tr>
                    <td>
                            <a href="#">Conversar</a>
                        </td>
                        <td>
                            <a href="#">Miquéias Silva</a>
                        </td>   
                        <td>30/05/2025</td>             
                        <td>Ativo</td>
                        <td>Levita</td>                    
                    </tr>                                          
                </tbody>
            </table>
        </div>
</div>