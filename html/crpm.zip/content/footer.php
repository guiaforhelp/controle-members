<?php
function footer(){
?>
<footer>
</footer>

</body>
</html>
<?php
}
?>