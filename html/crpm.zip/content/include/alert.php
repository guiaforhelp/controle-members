<?php
registreScript(array(        
    enqueueStyle('alert', 'alert', false, false))
);

function generationAlert(){
?>
<div id="alert-message" ></div>
<?php
}