<?php
/**
 * O app foi desenvolvido para auxiliar no controle de Membros da 
 * Igreja Cristo é a Resposta
 * 
 * Atualmente o app se encontra na versão beta de desenvolvimento
 * 
 * @version ${1:1.0.0}
 * @author miquéias Silva
 * @copyright 2023 CRPM
 * @package Control Members
 */

require 'content/function.php';
